package com.construction.companyManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

//public interface ServiceRepository extends JpaRepository<Service, Long> {}
