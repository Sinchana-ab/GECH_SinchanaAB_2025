package com.construction.companyManagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.construction.companyManagement.model.Admin;
import com.construction.companyManagement.repository.AdminRepository;

@Service
public class AdminService {

  //  @Autowired
  //  private AdminRepository adminRepo;

   // public boolean authenticate(String email, String password) {
  //      return adminRepo.findByEmailAndPassword(email, password).isPresent();
  //  }

    //public Admin getByEmail(String email) {
    //    return adminRepo.findByEmailAndPassword(email, "admin123").orElse(null);
    //}
}

