package com.coursemanagement.controller;

import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.coursemanagement.dto.ApiResponse;
import com.coursemanagement.dto.CertificateDTO;
import com.coursemanagement.dto.CourseDTO;
import com.coursemanagement.dto.UserDTO;
import com.coursemanagement.service.CertificateService;
import com.coursemanagement.service.CourseService;
import com.coursemanagement.service.UserService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"})
class CertificateController {

    private final CertificateService certificateService;

    public CertificateController(CertificateService certificateService) {
        this.certificateService = certificateService;
    }

    @PostMapping("/student/certificates/generate")
    @PreAuthorize("hasAnyRole('STUDENT', 'INSTRUCTOR', 'ADMIN')")
    public ResponseEntity<ApiResponse> generateCertificate(@RequestBody Map<String, Object> request) {
        try {
            Long studentId = Long.valueOf(request.get("studentId").toString());
            Long courseId = Long.valueOf(request.get("courseId").toString());
            Double finalScore = Double.valueOf(request.get("finalScore").toString());

            CertificateDTO certificate = certificateService.generateCertificate(studentId, courseId, finalScore);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ApiResponse(true, "Certificate generated successfully", certificate));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, e.getMessage(), null));
        }
    }

    @GetMapping("/student/certificates")
    @PreAuthorize("hasAnyRole('STUDENT', 'INSTRUCTOR', 'ADMIN')")
    public ResponseEntity<ApiResponse> getStudentCertificates(@RequestParam Long studentId) {
        try {
            List<CertificateDTO> certificates = certificateService.getStudentCertificates(studentId);
            return ResponseEntity.ok(new ApiResponse(true, "Certificates retrieved successfully", certificates));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse(false, e.getMessage(), null));
        }
    }

    @GetMapping("/public/certificates/verify/{certificateNumber}")
    public ResponseEntity<ApiResponse> verifyCertificate(@PathVariable String certificateNumber) {
        try {
            CertificateDTO certificate = certificateService.getCertificateByNumber(certificateNumber);
            return ResponseEntity.ok(new ApiResponse(true, "Certificate verified", certificate));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse(false, "Certificate not found", null));
        }
    }

    @GetMapping("/student/certificates/download/{id}")
    @PreAuthorize("hasAnyRole('STUDENT', 'INSTRUCTOR', 'ADMIN')")
    public ResponseEntity<byte[]> downloadCertificate(@PathVariable Long id) {
        try {
            byte[] pdfBytes = certificateService.generatePdfCertificate(id);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(
                ContentDisposition.builder("attachment")
                    .filename("certificate-" + id + ".pdf")
                    .build()
            );
            
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @GetMapping("/admin/certificates")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> getAllCertificates() {
        try {
            List<CertificateDTO> certificates = certificateService.getAllCertificates();
            return ResponseEntity.ok(new ApiResponse(true, "All certificates retrieved", certificates));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse(false, e.getMessage(), null));
        }
    }

    @DeleteMapping("/admin/certificates/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> deleteCertificate(@PathVariable Long id) {
        try {
            certificateService.deleteCertificate(id);
            return ResponseEntity.ok(new ApiResponse(true, "Certificate deleted successfully", null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, e.getMessage(), null));
        }
    }
}