package com.coursemanagement.config;

public class AsyncConfiguration {

}
